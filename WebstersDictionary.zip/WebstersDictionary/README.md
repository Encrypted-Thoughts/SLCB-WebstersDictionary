# SLCB-WebstersDictionary
Streamlabs chatbot script to get the Websters definition of a word for use in custom commands as a parameter.
